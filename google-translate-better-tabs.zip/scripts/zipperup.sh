# -r recursive
zip -r google-translate-better-tabs.zip .